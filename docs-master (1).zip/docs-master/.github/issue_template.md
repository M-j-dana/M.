---
name: Documentation feedback
about: Provide us with your feedback to help improve Codacy's documentation
title: ''
labels: ''
assignees: 

---

**Type of feedback**

-   [ ] Bug or incorrect information
-   [ ] Missing information
-   [ ] Outdated information
-   [ ] Enhancement
-   [ ] Other

**Feedback**

<!-- Write your feedback here -->

**Affected pages**
This feedback applies to the following documentation pages / URLs:

<!-- Add the URLs of the relevant pages -->

**Additional context**
If applicable, provide any other context or information that could be useful in updating the documentation:

<!-- Add extra information here -->
