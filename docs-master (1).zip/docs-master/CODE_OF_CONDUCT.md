# Code of conduct

This project follows the [Codacy Community Code of Conduct](https://community.codacy.com/t/code-of-conduct/19).
