!!! important
    For the sake of simplicity, the example doesn't consider paginated results obtained from the Codacy API. [Learn how to use pagination](../../codacy-api/using-the-codacy-api.md#using-pagination) to ensure that you process all results returned by the API.
