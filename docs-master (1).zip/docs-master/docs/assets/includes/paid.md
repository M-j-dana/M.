<!--paid-start-->
!!! info "This feature is [only available on paid plans](https://www.codacy.com/pricing)"
<!--paid-end-->

<!--paid-private-repositories-start-->
!!! info "Analyzing private repositories is [only available on paid plans](https://www.codacy.com/pricing)"
<!--paid-private-repositories-end-->

<!--paid-feature-start-->
!!! info "This is a [paid feature](https://www.codacy.com/pricing)"
<!--paid-feature-end>
