!!! tip
    Use a dedicated service account to integrate Codacy with your repositories. This prevents disruption of service if the user who originally enabled the integration loses access to the repositories, which may happen when a user leaves the team or the organization.

    For more information and instructions on how to set up a dedicated service account see [Why did Codacy stop commenting on pull requests?](../../faq/troubleshooting/why-did-codacy-stop-commenting-on-pull-requests.md)
