!!! important
    **To get a status for coverage** you must also:

    -   [Add coverage to your repository](../../coverage-reporter/index.md)
    -   Enable the rule **Diff coverage is under** or **Coverage variation is under** on the [pull request quality gate](../../repositories-configure/adjusting-quality-settings.md#gates).
