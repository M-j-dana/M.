# Does Codacy check for dependencies?

Codacy doesn't check for dependencies. Codacy performs static code analysis on the source code and checks for code style and security issues, duplication, complexity, and coverage.

To learn more on how to extend analysis on your repositories, see Codacy's [supported languages and tools](../../getting-started/supported-languages-and-tools.md).
