# How does Codacy keep my data secure?

Keeping our customers' data protected <span class="skip-vale">at all times</span> is our highest priority. This [security overview](https://security.codacy.com/) provides a high-level overview of the security practices put in place to achieve that objective.

Have questions or feedback? Feel free to reach out to us at <mailto:security@codacy.com>.
