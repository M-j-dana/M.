---
description: Codacy runs on every modern browser supporting HTML5 and CSS3.
---

# Which browsers does Codacy support?

Codacy runs on every modern browser supporting HTML5 and CSS3:

-   Chrome 67+
-   Firefox 45+
-   Internet Explorer 11+
-   Microsoft Edge 13+
