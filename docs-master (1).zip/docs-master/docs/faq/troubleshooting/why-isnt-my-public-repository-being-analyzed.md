# Why isn't my public repository being analyzed?

Codacy only analyzes open source repositories if the owner of the repository is a committer to that repository.
