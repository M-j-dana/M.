---
description: Instructions on how to run deadcode as a client-side tool on Codacy.
tool_name: deadcode
---

# Running deadcode

To run deadcode as a [client-side tool](client-side-tools.md):

<!-- NOTE
     include-markdown breaks the final list in two, use include instead. -->
{%
    include "../../assets/includes/client-side-tool-instructions.md"
    start="<!--instructions-start-->"
    end="<!--instructions-end-->"
%}

1.  Download and run the [Codacy Analysis CLI](https://github.com/codacy/codacy-analysis-cli#install) on the root of the repository, specifying the tool deadcode.

    ```bash
    codacy-analysis-cli analyze --tool deadcode \
                                --allow-network \
                                --upload \
                                --verbose
    ```

    **If you're using an account API token**, you must also provide the flags `--provider`, `--username`, and `--project`. You can obtain the values for these flags from the URL of your repository dashboard on Codacy:

    ```bash
    codacy-analysis-cli analyze --provider <gh, ghe, gl, gle, bb, or bbe> \
                                --username <name of your Codacy organization> \
                                --project <name of your repository> \
                                --tool deadcode \
                                --allow-network \
                                --upload \
                                --verbose
    ```

The Codacy Analysis CLI runs deadcode on your repository and uploads the results to Codacy so you can use them in your workflow.

{%
    include-markdown "../../assets/includes/client-side-tool-instructions.md"
    start="<!--advanced-start-->"
    end="<!--advanced-end-->"
%}
